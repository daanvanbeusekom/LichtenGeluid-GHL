<?php
//Server account
$db_servername = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "lgweb";

?>