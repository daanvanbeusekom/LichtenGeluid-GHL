
	  $(document).ready(function() {
 		 $('#modal1').openModal();
         $('#model1').modal({
             opacity: .5, // Opacity of modal background
         })
		});
